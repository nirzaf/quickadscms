<?php
$config['db']['host'] = 'localhost';
$config['db']['name'] = 'agency';
$config['db']['user'] = 'root';
$config['db']['pass'] = '';
$config['db']['pre'] = 'ad_';

$config['version'] = '8.2';
$config['installed'] = '1';
?>