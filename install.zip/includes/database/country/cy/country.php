<?php return array(
    'UK' => 'Prydain Fawr',
    'CC' => 'Ynysoedd Cocos [Keeling]',
);
